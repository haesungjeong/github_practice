from concurrent import futures
import time
import sys
import grpc
import logging
sys.path.append("./grpc_compiled")
import hello_pb2
import hello_pb2_grpc

logger = logging.getLogger(__name__)

class Greeter(hello_pb2_grpc.GreeterServicer):
    def SayHello(self, request, context):
        #time.sleep(0.5)
        #names = request.name
        #print(f'name is , {request.name}, email is {request.email}, password is {request.password}, department is {request.department}')
        return hello_pb2.HelloReply(message=f'name is , {request.name}, email is {request.email}, password is {request.password}, department is {request.department}')
    
def serve():
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10000))
    hello_pb2_grpc.add_GreeterServicer_to_server(Greeter(), server)
    #server.add_insecure_port('localhost:50051')
    server.add_insecure_port('[::]:5001')
 
    server.start()
    logger.info("gRPC server started")
    server.wait_for_termination()


if __name__ == '__main__':
    serve()