1. proto파일을 grpc python protocol compiler로 변환 필요 
hello.proto 파일 생성 후 아래 명령어 실행하여 hello_pb2_grpc.py, hello_pb2.py 파일 생성
python3 -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. hello.proto

2. GUI환경 실행
locustfile.py 있는 경로에서 커맨드라인에 locust 입력후 http://localhost:8089/ 접속

3. CLI환경 실행 (변수조절가능)
locust -f locustfile.py --headless -u 1 --spawn-rate 1 --run-time 1m