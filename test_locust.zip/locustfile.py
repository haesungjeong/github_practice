import gevent
import grpc_user
from test_server import serve
import sys
from locust import events, task, constant
import torch
sys.path.append("./grpc_compiled")
import hello_pb2
import hello_pb2_grpc
import time
import logging

@events.init.add_listener
def run_grpc_server(environment, **_kwargs):
    gevent.spawn(serve)

class nlcgrpcuser(grpc_user.GrpcUser):
    host = "localhost:5001"
    #host = "192.168.219.106:50051"
    stub_class = hello_pb2_grpc.GreeterStub
    #wait_time = constant(1)
    
    @task
    def nlc(self):
        query_server = hello_pb2.HelloRequest(
            name='정해성', email='suncastle@lguplus.co.kr', 
            password=1234, department='NLP기술팀')
        self.stub.SayHello(query_server)
        #time.sleep(0.02)